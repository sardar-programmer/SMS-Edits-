import React from 'react';
import './services.css';

const ServicesSection = () => {
  const services = [
    {
      icon: '✨',
      title: 'Basic Edit',
      description: 'Color correction, exposure adjustment, and basic retouching to enhance your photos naturally.',
      price: '$2.5',
      buttonText: 'Order Now'
    },
    {
      icon: '🎨',
      title: 'Creative Edit',
      description: 'Artistic transformations, special effects, and creative compositing for stunning visual impact.',
      price: '$8',
      buttonText: 'Get Started'
    },
    {
      icon: '💁‍♂️',
      title: 'Face Retouch',
      description: 'Professional portrait retouching including skin smoothing, blemish removal, and feature enhancement.',
      price: '$5',
      buttonText: 'Order Now'
    },
    {
      icon: '🔥',
      title: 'Premium Package',
      description: 'Complete photo makeover with advanced techniques, multiple revisions, and priority support.',
      price: 'Custom',
      buttonText: 'Get Quote'
    }
  ];

  return (
    <section className="services-section">
      <div className="services-container">
        <div className="services-header">
          <h2 className="services-title">Services I Offer</h2>
          <p className="services-subtitle">
            Tailored photo editing solutions that bring your images to life.
          </p>
        </div>
        
        <div className="services-grid">
          {services.map((service, index) => (
            <div key={index} className="service-card">
              <div className="service-icon">{service.icon}</div>
              <h3 className="service-title">{service.title}</h3>
              <p className="service-description">{service.description}</p>
              <div className="service-price">{service.price}</div>
              <button className="service-button">{service.buttonText}</button>
            </div>
          ))}
        </div>
        
        <div className="services-footer">
          <p>Need something custom? <span className="contact-link">Contact me directly.</span></p>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;