import React, { useState, useEffect } from 'react';
import { X, ExternalLink, Instagram, ChevronLeft, ChevronRight } from 'lucide-react';
import img1 from './image/img-1.jpg';
import img2 from './image/img-2.jpg';
import img3 from './image/img-3.jpg';
import img4 from './image/img-4.jpg';
import img5 from './image/img-5.jpg';
import img6 from './image/img-6.jpg';
import img7 from './image/img-7.jpg';
import img8 from './image/img-8.jpg';
import img9 from './image/img-9.png';
import img10 from './image/img-10.png';


const PortfolioGallery = () => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedImage, setSelectedImage] = useState(null);
  const [isVisible, setIsVisible] = useState(false);

  // Sample portfolio data - replace with your actual images
  const portfolioItems = [
    {
      id: 1,
      src: img1,
      category: 'Retouching',
      title: 'Portrait Enhancement',
      tag: 'THe Owner OF This Website'
    },
    {
      id: 2,
      src: img2,
      category: 'Before & After',
      title: 'Skin Perfection',
      tag: 'Clinte Works'
    },
    {
      id: 3,
      src: img3,
      category: 'Creative Manipulation',
      title: 'Artistic Vision',
      tag: 'For Clinte DP'
    },
    {
      id: 4,
      src: img4,
      category: 'Background Removal',
      title: 'Clean Extraction',
      tag: 'Client Work'
    },
    {
      id: 5,
      src: img5,
      category: 'Retouching',
      title: 'Professional Polish',
      tag: 'Website Owner'
    },
    {
      id: 6,
      src: img6,
      category: 'Creative Manipulation',
      title: 'Color Grading',
      tag: 'Iphone Editing'
    },
    {
      id: 7,
      src: img7,
      category: 'Before & After',
      title: 'Dramatic Transform',
      tag: 'Website Owner'
    },
    {
      id: 8,
      src: img8,
      category: 'Retouching',
      title: 'Natural Enhancement',
      tag: 'Personal Project'
    },
    {
      id: 9,
      src: img9,
      category:'Before & After',
      title:'Natural beuty',
      tag: 'owner pic'
    },
    {
      id: 10,
      src: img10,
      category: 'Retouching',
      title: 'smart editing',
      tag: 'handsome owner pic'
    }
  ];

  const categories = ['All', 'Before & After', 'Retouching', 'Background Removal', 'Creative Manipulation'];

  const filteredItems = activeFilter === 'All' 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === activeFilter);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const section = document.getElementById('portfolio-section');
    if (section) observer.observe(section);

    return () => observer.disconnect();
  }, []);

  const openModal = (item) => {
    setSelectedImage(item);
    document.body.style.overflow = 'hidden';
  };

  const closeModal = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'unset';
  };

  const navigateImage = (direction) => {
    const currentIndex = filteredItems.findIndex(item => item.id === selectedImage.id);
    const newIndex = direction === 'next' 
      ? (currentIndex + 1) % filteredItems.length
      : (currentIndex - 1 + filteredItems.length) % filteredItems.length;
    setSelectedImage(filteredItems[newIndex]);
  };

  return (
    <>
      <section id="portfolio-section" className="portfolio-section">
        <div className="container">
          {/* Header */}
          <div className={`portfolio-header ${isVisible ? 'animate-in' : ''}`}>
            <h2 className="section-title">My Work</h2>
            <p className="section-subtitle">A Glimpse into My Editing Magic</p>
          </div>

          {/* Filter Buttons */}
          <div className={`filter-container ${isVisible ? 'animate-in' : ''}`}>
            {categories.map((category) => (
              <button
                key={category}
                className={`filter-btn ${activeFilter === category ? 'active' : ''}`}
                onClick={() => setActiveFilter(category)}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Image Grid */}
          <div className={`portfolio-grid ${isVisible ? 'animate-in' : ''}`}>
            {filteredItems.map((item, index) => (
              <div
                key={item.id}
                className="portfolio-item"
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={() => openModal(item)}
              >
                <div className="image-container">
                  <img src={item.src} alt={item.title} />
                  <div className="image-overlay">
                    <div className="overlay-content">
                      <h3>{item.title}</h3>
                      <p>{item.category}</p>
                    </div>
                  </div>
                  <div className="image-tag">{item.tag}</div>
                  <div className="watermark">@SMS_Edits</div>
                </div>
              </div>
            ))}
          </div>

          {/* CTA Button */}
          <div className={`cta-container ${isVisible ? 'animate-in' : ''}`}>
            <button className="cta-button secondary">
              <ExternalLink size={20} />
              Request Similar Edit
            </button>
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedImage && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={closeModal}>
              <X size={24} />
            </button>
            
            <button className="modal-nav prev" onClick={() => navigateImage('prev')}>
              <ChevronLeft size={24} />
            </button>
            
            <button className="modal-nav next" onClick={() => navigateImage('next')}>
              <ChevronRight size={24} />
            </button>

            <div className="modal-image-container">
              <img src={selectedImage.src} alt={selectedImage.title} />
              <div className="modal-info">
                <h3>{selectedImage.title}</h3>
                <p>{selectedImage.category}</p>
                <span className="modal-tag">{selectedImage.tag}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .portfolio-section {
          background: linear-gradient(135deg, #0f0f0f 0%, #1a1a1a 50%, #0f0f0f 100%);
          padding: 100px 0;
          min-height: 100vh;
          color: white;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          position: relative;
          overflow: hidden;
        }

        .portfolio-section::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(ellipse at center, rgba(255, 20, 147, 0.1) 0%, transparent 70%);
          pointer-events: none;
        }

        .container {
          max-width: 1400px;
          margin: 0 auto;
          padding: 0 20px;
          position: relative;
          z-index: 1;
        }

        .portfolio-header {
          text-align: center;
          margin-bottom: 60px;
          opacity: 0;
          transform: translateY(30px);
          transition: all 0.8s ease;
        }

        .portfolio-header.animate-in {
          opacity: 1;
          transform: translateY(0);
        }

        .section-title {
          font-size: 3.5rem;
          font-weight: 700;
          margin-bottom: 20px;
          background: linear-gradient(135deg, #fff 0%, #ff1493 50%, #00bfff 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          line-height: 1.2;
        }

        .section-subtitle {
          font-size: 1.3rem;
          color: #b0b0b0;
          font-weight: 300;
          max-width: 600px;
          margin: 0 auto;
          line-height: 1.6;
        }

        .filter-container {
          display: flex;
          justify-content: center;
          gap: 15px;
          margin-bottom: 60px;
          flex-wrap: wrap;
          opacity: 0;
          transform: translateY(20px);
          transition: all 0.8s ease 0.2s;
        }

        .filter-container.animate-in {
          opacity: 1;
          transform: translateY(0);
        }

        .filter-btn {
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: #b0b0b0;
          padding: 12px 24px;
          border-radius: 30px;
          cursor: pointer;
          transition: all 0.3s ease;
          font-weight: 500;
          backdrop-filter: blur(10px);
        }

        .filter-btn:hover {
          background: rgba(255, 20, 147, 0.1);
          border-color: rgba(255, 20, 147, 0.3);
          color: #ff1493;
          transform: translateY(-2px);
        }

        .filter-btn.active {
          background: linear-gradient(135deg, #ff1493, #00bfff);
          border-color: transparent;
          color: white;
          box-shadow: 0 10px 30px rgba(255, 20, 147, 0.3);
        }

        .portfolio-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 30px;
          margin-bottom: 80px;
        }

        .portfolio-item {
          opacity: 0;
          transform: translateY(50px) scale(0.9);
          animation: slideInUp 0.8s ease forwards;
          cursor: pointer;
        }

        .portfolio-grid.animate-in .portfolio-item {
          animation-play-state: running;
        }

        @keyframes slideInUp {
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        .image-container {
          position: relative;
          border-radius: 20px;
          overflow: hidden;
          background: rgba(255, 255, 255, 0.02);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.05);
          transition: all 0.4s ease;
          box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        }

        .image-container:hover {
          transform: translateY(-10px);
          box-shadow: 0 20px 60px rgba(255, 20, 147, 0.2);
          border-color: rgba(255, 20, 147, 0.2);
        }

        .image-container img {
          width: 100%;
          height: 400px;
          object-fit: cover;
          transition: transform 0.4s ease;
        }

        .image-container:hover img {
          transform: scale(1.05);
        }

        .image-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, rgba(255, 20, 147, 0.8), rgba(0, 191, 255, 0.8));
          opacity: 0;
          transition: all 0.4s ease;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .image-container:hover .image-overlay {
          opacity: 1;
        }

        .overlay-content {
          text-align: center;
          transform: translateY(20px);
          transition: transform 0.4s ease;
        }

        .image-container:hover .overlay-content {
          transform: translateY(0);
        }

        .overlay-content h3 {
          font-size: 1.5rem;
          font-weight: 600;
          margin-bottom: 8px;
        }

        .overlay-content p {
          font-size: 1rem;
          opacity: 0.9;
        }

        .image-tag {
          position: absolute;
          top: 15px;
          left: 15px;
          background: rgba(0, 0, 0, 0.7);
          color: white;
          padding: 6px 12px;
          border-radius: 15px;
          font-size: 0.8rem;
          font-weight: 500;
          backdrop-filter: blur(10px);
        }

        .watermark {
          position: absolute;
          bottom: 15px;
          right: 15px;
          background: rgba(0, 0, 0, 0.7);
          color: white;
          padding: 4px 8px;
          border-radius: 10px;
          font-size: 0.7rem;
          opacity: 0.8;
          backdrop-filter: blur(10px);
        }

        .cta-container {
          display: flex;
          justify-content: center;
          gap: 20px;
          flex-wrap: wrap;
          opacity: 0;
          transform: translateY(20px);
          transition: all 0.8s ease 0.4s;
        }

        .cta-container.animate-in {
          opacity: 1;
          transform: translateY(0);
        }

        .cta-button {
          display: flex;
          align-items: center;
          gap: 10px;
          background: linear-gradient(135deg, #ff1493, #00bfff);
          border: none;
          color: white;
          padding: 15px 30px;
          border-radius: 50px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s ease;
          font-size: 1rem;
        }

        .cta-button:hover {
          transform: translateY(-3px);
          box-shadow: 0 15px 40px rgba(255, 20, 147, 0.4);
        }

        .cta-button.secondary {
          background: rgba(255, 255, 255, 0.1);
          border: 1px solid rgba(255, 255, 255, 0.2);
          backdrop-filter: blur(10px);
        }

        .cta-button.secondary:hover {
          background: rgba(255, 255, 255, 0.15);
          box-shadow: 0 15px 40px rgba(255, 255, 255, 0.1);
        }

        /* Modal Styles */
        .modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.9);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          animation: fadeIn 0.3s ease;
          backdrop-filter: blur(20px);
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .modal-content {
          position: relative;
          max-width: 90vw;
          max-height: 90vh;
          animation: scaleIn 0.3s ease;
        }

        @keyframes scaleIn {
          from { transform: scale(0.8); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }

        .modal-close {
          position: absolute;
          top: -50px;
          right: 0;
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          padding: 10px;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s ease;
          backdrop-filter: blur(10px);
        }

        .modal-close:hover {
          background: rgba(255, 20, 147, 0.2);
          transform: scale(1.1);
        }

        .modal-nav {
          position: absolute;
          top: 50%;
          transform: translateY(-50%);
          background: rgba(255, 255, 255, 0.1);
          border: none;
          color: white;
          padding: 15px;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.3s ease;
          backdrop-filter: blur(10px);
        }

        .modal-nav:hover {
          background: rgba(255, 20, 147, 0.2);
          transform: translateY(-50%) scale(1.1);
        }

        .modal-nav.prev {
          left: -70px;
        }

        .modal-nav.next {
          right: -70px;
        }

        .modal-image-container img {
          max-width: 100%;
          max-height: 80vh;
          border-radius: 15px;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }

        .modal-info {
          text-align: center;
          margin-top: 20px;
        }

        .modal-info h3 {
          font-size: 1.5rem;
          margin-bottom: 8px;
        }

        .modal-info p {
          color: #b0b0b0;
          margin-bottom: 10px;
        }

        .modal-tag {
          background: linear-gradient(135deg, #ff1493, #00bfff);
          padding: 6px 15px;
          border-radius: 15px;
          font-size: 0.9rem;
          font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .section-title {
            font-size: 2.5rem;
          }

          .section-subtitle {
            font-size: 1.1rem;
          }

          .portfolio-grid {
            grid-template-columns: 1fr;
            gap: 20px;
          }

          .image-container img {
            height: 300px;
          }

          .cta-container {
            flex-direction: column;
            align-items: center;
          }

          .modal-nav {
            display: none;
          }

          .modal-content {
            max-width: 95vw;
          }
        }

        @media (max-width: 480px) {
          .container {
            padding: 0 15px;
          }

          .filter-container {
            gap: 10px;
          }

          .filter-btn {
            padding: 10px 18px;
            font-size: 0.9rem;
          }
        }
      `}</style>
    </>
  );
};

export default PortfolioGallery;