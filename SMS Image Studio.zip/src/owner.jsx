import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Sparkles, Wrench, Terminal, Users, Eye } from 'lucide-react';
import img10 from './image/img-10.png';

const OwnerVisionSection = () => {
  const [isHovered, setIsHovered] = useState(false);
  const [glitchActive, setGlitchActive] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setGlitchActive(true);
      setTimeout(() => setGlitchActive(false), 200);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        
        .owner-vision-container {
          min-height: 100vh;
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 25%, #0f3460 50%, #533483 100%);
          color: white;
          font-family: 'Inter', sans-serif;
          position: relative;
          overflow: hidden;
          padding: 60px 20px;
        }

        .owner-vision-container::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: 
            radial-gradient(circle at 20% 20%, rgba(230, 0, 35, 0.1) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(230, 0, 35, 0.05) 0%, transparent 50%);
          pointer-events: none;
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
          position: relative;
          z-index: 1;
        }

        .section-header {
          text-align: center;
          margin-bottom: 80px;
        }

        .section-title {
          font-family: 'Inter', sans-serif;
          font-size: 3.5rem;
          font-weight: 900;
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          color: transparent;
          margin-bottom: 20px;
          text-transform: uppercase;
          letter-spacing: 4px;
        }

        .section-subtitle {
          font-size: 1.3rem;
          color: #cccccc;
          font-weight: 300;
          letter-spacing: 2px;
        }

        .content-grid {
          display: grid;
          grid-template-columns: 1fr 2fr;
          gap: 80px;
          align-items: center;
        }

        .avatar-section {
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
        }

        .avatar-container {
          position: relative;
          width: 280px;
          height: 280px;
          margin-bottom: 30px;
        }

        .avatar-border {
          position: absolute;
          inset: -4px;
          border-radius: 50%;
          background: linear-gradient(45deg, #e60023, #ff1744, #e60023);
          animation: rotate 4s linear infinite;
        }

        .avatar-border.glitch {
          animation: glitchBorder 0.2s ease-in-out;
        }

        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @keyframes glitchBorder {
          0% { filter: hue-rotate(0deg); }
          25% { filter: hue-rotate(90deg); }
          50% { filter: hue-rotate(180deg); }
          75% { filter: hue-rotate(270deg); }
          100% { filter: hue-rotate(360deg); }
        }

        .avatar-inner {
          position: relative;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background: linear-gradient(135deg, #1a1a1a, #333333);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }

        .avatar-icon {
          width: 300px;
          height: 300px;
          color: #e60023;
          filter: drop-shadow(0 0 20px rgba(230, 0, 35, 0.5));
        }

        .role-badge {
          background: linear-gradient(45deg, #e60023, #ff1744);
          padding: 12px 24px;
          border-radius: 25px;
          font-family: 'Inter', sans-serif;
          font-weight: 700;
          font-size: 1.1rem;
          letter-spacing: 1px;
          box-shadow: 0 0 30px rgba(230, 0, 35, 0.3);
          text-transform: uppercase;
        }

        .content-section {
          padding-left: 40px;
        }

        .content-title {
          font-family: 'Inter', sans-serif;
          font-size: 2.8rem;
          font-weight: 700;
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          color: transparent;
          margin-bottom: 40px;
          position: relative;
        }

        .content-title::after {
          content: '';
          position: absolute;
          bottom: -10px;
          left: 0;
          width: 80px;
          height: 3px;
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
        }

        .content-paragraph {
          font-size: 1.25rem;
          line-height: 1.8;
          color: #e0e0e0;
          margin-bottom: 35px;
          font-weight: 400;
        }

        .highlight-text {
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          color: transparent;
          font-weight: 600;
        }

        .vision-card {
          background: rgba(230, 0, 35, 0.1);
          border: 1px solid rgba(230, 0, 35, 0.3);
          border-radius: 15px;
          padding: 30px;
          margin: 40px 0;
          backdrop-filter: blur(10px);
          position: relative;
          overflow: hidden;
        }

        .vision-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
          animation: shimmer 3s infinite;
        }

        @keyframes shimmer {
          0% { left: -100%; }
          100% { left: 100%; }
        }

        .vision-title {
          font-family: 'Inter', sans-serif;
          font-size: 1.4rem;
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          color: transparent;
          margin-bottom: 15px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .vision-text {
          font-size: 1.1rem;
          color: #f0f0f0;
          font-weight: 500;
        }

        .future-button {
          background: linear-gradient(45deg, #333333, #555555);
          color: #888888;
          border: 2px solid #444444;
          padding: 15px 35px;
          border-radius: 8px;
          font-family: 'Inter', sans-serif;
          font-weight: 600;
          font-size: 1rem;
          cursor: not-allowed;
          position: relative;
          text-transform: uppercase;
          letter-spacing: 1px;
          margin-top: 20px;
          transition: all 0.3s ease;
        }

        .future-button:hover {
          border-color: #e60023;
          color: #e60023;
          box-shadow: 0 0 20px rgba(230, 0, 35, 0.2);
        }

        .tooltip {
          position: absolute;
          bottom: 120%;
          left: 50%;
          transform: translateX(-50%);
          background: #e60023;
          color: white;
          padding: 8px 12px;
          border-radius: 6px;
          font-size: 0.9rem;
          white-space: nowrap;
          opacity: 0;
          visibility: hidden;
          transition: all 0.3s ease;
        }

        .tooltip::after {
          content: '';
          position: absolute;
          top: 100%;
          left: 50%;
          transform: translateX(-50%);
          border: 5px solid transparent;
          border-top-color: #e60023;
        }

        .future-button:hover .tooltip {
          opacity: 1;
          visibility: visible;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
          margin-top: 40px;
        }

        .stat-item {
          text-align: center;
          padding: 20px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
          border: 1px solid rgba(230, 0, 35, 0.2);
        }

        .stat-number {
          font-family: 'Inter', sans-serif;
          font-size: 2rem;
          font-weight: 700;
          background: linear-gradient(135deg, #a855f7 0%, #ec4899 50%, #3b82f6 100%);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
          color: transparent;
        }

        .stat-label {
          font-size: 0.9rem;
          color: #cccccc;
          margin-top: 5px;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
          .owner-vision-container {
            padding: 40px 15px;
          }

          .section-title {
            font-size: 2.5rem;
            letter-spacing: 2px;
          }

          .content-grid {
            grid-template-columns: 1fr;
            gap: 50px;
            text-align: center;
          }

          .content-section {
            padding-left: 0;
          }

          .avatar-container {
            width: 220px;
            height: 220px;
          }

          .avatar-icon {
            width: 250px;
            height: 250px;
          }

          .content-title {
            font-size: 2.2rem;
          }

          .content-paragraph {
            font-size: 1.1rem;
          }

          .stats-grid {
            grid-template-columns: 1fr;
            gap: 15px;
          }

          .vision-card {
            padding: 25px 20px;
          }
        }

        @media (max-width: 480px) {
          .section-title {
            font-size: 2rem;
          }

          .content-title {
            font-size: 1.8rem;
          }

          .avatar-container {
            width: 180px;
            height: 180px;
          }

          .avatar-icon {
            width: 200px;
            height: 200px;
          }
        }
      `}</style>

      <section className="owner-vision-container">
        <div className="container">
          <motion.div 
            className="section-header"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="section-title">Owner & Vision</h2>
            <p className="section-subtitle">The Mind Behind the Code</p>
          </motion.div>

          <div className="content-grid">
            <motion.div 
              className="avatar-section"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="avatar-container">
                <div className={`avatar-border ${glitchActive ? 'glitch' : ''}`}></div>
                <div className="avatar-inner">
                  {/* <User className="avatar-icon" /> */}
                    <img src={img10} alt="Owner Avatar" className="avatar-icon" />
                </div>
              </div>
              <motion.div 
                className="role-badge"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                👨‍💻 Solo Builder
              </motion.div>
            </motion.div>

            <motion.div 
              className="content-section"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <h3 className="content-title">Meet the Creator</h3>
              
              <motion.p 
                className="content-paragraph"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                I'm <span className="highlight-text">SM3S</span> – the solo brain behind this digital world. 
                Every pixel, every animation, every interaction — <span className="highlight-text">handcrafted by me</span>. 
                I currently work alone, with no team... yet.
              </motion.p>

              <motion.p 
                className="content-paragraph"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 }}
              >
                But the mission has already begun. I'm building toward a future — a team of creators, 
                dreamers, and coders who will <span className="highlight-text">shape digital experiences together</span>.
              </motion.p>

              <motion.div 
                className="vision-card"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: 1.0 }}
              >
                <div className="vision-title">
                  <Users size={24} />
                  🚧 Team Section: Coming Soon...
                </div>
                <p className="vision-text">
                  The future holds endless possibilities. Soon, this solo journey will evolve 
                  into a collective force of innovation and creativity.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.2 }}
              >
                <button 
                  className="future-button"
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  Join the Future Team
                  <div className="tooltip">Launching Soon</div>
                </button>
              </motion.div>

              <motion.div 
                className="stats-grid"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.4 }}
              >
                <div className="stat-item">
                  <div className="stat-number">1</div>
                  <div className="stat-label">Solo Developer</div>
                </div>
                <div className="stat-item">
                  <div className="stat-number">∞</div>
                  <div className="stat-label">Possibilities</div>
                </div>
                <div className="stat-item">
                  <div className="stat-number">?</div>
                  <div className="stat-label">Future Team Size</div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default OwnerVisionSection;