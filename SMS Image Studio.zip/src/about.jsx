import React, { useState, useEffect } from 'react';
import { Eye, Palette, Heart, Coffee, Music, Zap, Camera, Star, Award, Users } from 'lucide-react';

const AboutMe = () => {
  const [scrollY, setScrollY] = useState(0);
  const [visibleSections, setVisibleSections] = useState(new Set());

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisibleSections(prev => new Set([...prev, entry.target.id]));
          }
        });
      },
      { threshold: 0.1 }
    );

    document.querySelectorAll('[id]').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const skills = [
    { icon: <Palette />, name: "Adobe Photoshop", desc: "Advanced retouching and manipulation" },
    { icon: <Camera />, name: "Lightroom", desc: "Professional color grading mastery" },
    { icon: <Eye />, name: "Retouching", desc: "Pixel-perfect skin and object refinement" },
    { icon: <Star />, name: "Color Grading", desc: "Mood transformation through color" },
    { icon: <Zap />, name: "Background Replacement", desc: "Seamless environment swapping" },
    { icon: <Heart />, name: "Instagram-Ready Designs", desc: "Social media optimization" }
  ];

  const milestones = [
    { year: "2021", event: "First edit - discovered my passion" },
    { year: "2022", event: "100+ photos edited, style developing" },
    { year: "2023", event: "First paid client, business begins" },
    { year: "2024", event: "50+ happy clients, portfolio established" }
  ];

  const funFacts = [
    { icon: "🎧", text: "I edit while listening to Lo-Fi beats" },
    { icon: "🥤", text: "My brain runs on Mountain Dew" },
    { icon: "💻", text: "I believe in pixels with purpose" },
    { icon: "🇵🇰", text: "Proudly editing from Pakistan" }
  ];

  return (
    <div className="about-container">
      <style jsx>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        .about-container {
          font-family: 'Poppins', sans-serif;
          background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
          color: #ffffff;
          min-height: 100vh;
          overflow-x: hidden;
        }

        .hero-section {
          height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          position: relative;
          background: linear-gradient(45deg, rgba(0,212,255,0.1) 0%, rgba(255,0,150,0.1) 100%);
        }

        .hero-bg {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: 
            radial-gradient(circle at 20% 80%, rgba(120,119,198,0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 20%, rgba(255,119,198,0.3) 0%, transparent 50%),
            radial-gradient(circle at 40% 40%, rgba(120,200,255,0.2) 0%, transparent 50%);
          animation: float 20s ease-in-out infinite;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-content {
          position: relative;
          z-index: 2;
          animation: fadeInUp 1s ease-out;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(50px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .hero-title {
          font-size: clamp(2.5rem, 6vw, 4.5rem);
          font-weight: 700;
          background: linear-gradient(45deg, #00d4ff, #ff4081, #ffeb3b);
          background-size: 200% 200%;
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          animation: gradientShift 3s ease-in-out infinite;
          margin-bottom: 1rem;
          line-height: 1.2;
        }

        @keyframes gradientShift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }

        .hero-subtitle {
          font-size: clamp(1.2rem, 3vw, 1.8rem);
          font-weight: 300;
          opacity: 0.9;
          margin-bottom: 2rem;
          animation: fadeInUp 1s ease-out 0.3s both;
        }

        .section {
          padding: 5rem 2rem;
          max-width: 1200px;
          margin: 0 auto;
          opacity: 0;
          transform: translateY(50px);
          transition: all 0.8s ease-out;
        }

        .section.visible {
          opacity: 1;
          transform: translateY(0);
        }

        .section-title {
          font-size: clamp(2rem, 4vw, 3rem);
          font-weight: 600;
          margin-bottom: 3rem;
          text-align: center;
          position: relative;
        }

        .section-title::after {
          content: '';
          position: absolute;
          bottom: -10px;
          left: 50%;
          transform: translateX(-50%);
          width: 80px;
          height: 3px;
          background: linear-gradient(45deg, #00d4ff, #ff4081);
          border-radius: 2px;
        }

        .story-content {
          display: grid;
          grid-template-columns: 1fr 300px;
          gap: 4rem;
          align-items: start;
        }

        .story-text {
          font-size: 1.1rem;
          line-height: 1.8;
          opacity: 0.9;
        }

        .story-text p {
          margin-bottom: 1.5rem;
        }

        .quote {
          font-style: italic;
          font-size: 1.3rem;
          text-align: center;
          margin: 3rem 0;
          padding: 2rem;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 15px;
          border-left: 4px solid #00d4ff;
          position: relative;
        }

        .quote::before {
          content: '"';
          position: absolute;
          top: -10px;
          left: 20px;
          font-size: 4rem;
          color: #00d4ff;
          opacity: 0.5;
        }

        .timeline {
          display: flex;
          flex-direction: column;
          gap: 2rem;
        }

        .milestone {
          background: rgba(255, 255, 255, 0.05);
          padding: 1.5rem;
          border-radius: 10px;
          border-left: 4px solid #ff4081;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .milestone:hover {
          transform: translateX(10px);
          box-shadow: 0 10px 30px rgba(255, 64, 129, 0.2);
        }

        .milestone-year {
          font-weight: 600;
          color: #ff4081;
          font-size: 1.2rem;
        }

        .milestone-event {
          opacity: 0.9;
          margin-top: 0.5rem;
        }

        .skills-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
          margin-top: 3rem;
        }

        .skill-card {
          background: rgba(255, 255, 255, 0.05);
          padding: 2rem;
          border-radius: 15px;
          text-align: center;
          transition: all 0.3s ease;
          border: 1px solid rgba(255, 255, 255, 0.1);
          position: relative;
          overflow: hidden;
        }

        .skill-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
          transition: left 0.5s;
        }

        .skill-card:hover::before {
          left: 100%;
        }

        .skill-card:hover {
          transform: translateY(-10px);
          box-shadow: 0 20px 40px rgba(0, 212, 255, 0.2);
          border-color: #00d4ff;
        }

        .skill-icon {
          width: 60px;
          height: 60px;
          margin: 0 auto 1rem;
          color: #00d4ff;
        }

        .skill-name {
          font-size: 1.3rem;
          font-weight: 600;
          margin-bottom: 0.5rem;
        }

        .skill-desc {
          opacity: 0.8;
          font-size: 0.95rem;
        }

        .fun-facts {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
          margin-top: 3rem;
        }

        .fun-fact {
          background: rgba(255, 255, 255, 0.03);
          padding: 2rem;
          border-radius: 15px;
          text-align: center;
          transition: all 0.3s ease;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .fun-fact:hover {
          transform: scale(1.05);
          background: rgba(255, 255, 255, 0.08);
        }

        .fun-fact-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
          display: block;
        }

        .fun-fact-text {
          font-size: 1.1rem;
          opacity: 0.9;
        }

        .cta-section {
          text-align: center;
          padding: 4rem 2rem;
          background: linear-gradient(45deg, rgba(0,212,255,0.1), rgba(255,0,150,0.1));
        }

        .cta-button {
          display: inline-block;
          padding: 1rem 2rem;
          background: linear-gradient(45deg, #00d4ff, #ff4081);
          color: white;
          text-decoration: none;
          border-radius: 50px;
          font-weight: 600;
          font-size: 1.1rem;
          transition: all 0.3s ease;
          text-transform: uppercase;
          letter-spacing: 1px;
        }

        .cta-button:hover {
          transform: translateY(-3px);
          box-shadow: 0 15px 30px rgba(0, 212, 255, 0.4);
        }

        .closing-quote {
          background: rgba(0, 0, 0, 0.3);
          padding: 3rem;
          text-align: center;
          font-size: 1.4rem;
          font-style: italic;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        @media (max-width: 768px) {
          .story-content {
            grid-template-columns: 1fr;
            gap: 2rem;
          }
          
          .skills-grid {
            grid-template-columns: 1fr;
          }
          
          .fun-facts {
            grid-template-columns: repeat(2, 1fr);
          }
          
          .section {
            padding: 3rem 1rem;
          }
        }

        @media (max-width: 480px) {
          .fun-facts {
            grid-template-columns: 1fr;
          }
        }
      `}</style>

      {/* Hero Section */}
      <section className="hero-section" id="hero">
        <div className="hero-bg"></div>
        <div className="hero-content">
          <h1 className="hero-title">
            I'm Sardar Mustafa Shafi – The Man Behind The Magic
          </h1>
          <p className="hero-subtitle">
            Turning emotions into edits — one pixel at a time.
          </p>
        </div>
      </section>

      {/* My Story Section */}
      <section className={`section ${visibleSections.has('story') ? 'visible' : ''}`} id="story">
        <h2 className="section-title">My Journey</h2>
        <div className="story-content">
          <div className="story-text">
            <p>
              My journey into photo editing began in 2021, not by chance, but by passion. Growing up watching my father work in the mines, I learned that every detail matters—whether you're extracting precious minerals from the earth or extracting the perfect emotion from a photograph.
            </p>
            <p>
              What started as curiosity quickly became obsession. I found myself spending hours perfecting a single edit, not because I had to, but because I could feel the story the image wanted to tell. Each photo carries an emotion, a memory, a moment that deserves to be honored.
            </p>
            <p>
              Today, I don't just edit photos—I collaborate with dreams. When a client trusts me with their vision, I blend my technical expertise with their emotional connection to create something that speaks to the soul. Every pixel has purpose, every adjustment has meaning.
            </p>
            
            <div className="quote">
              Har tasveer mein ek jazba hota hai — main usay mehsoos karta hoon.
            </div>
          </div>
          
          <div className="timeline">
            {milestones.map((milestone, index) => (
              <div key={index} className="milestone">
                <div className="milestone-year">{milestone.year}</div>
                <div className="milestone-event">{milestone.event}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills & Tools Section */}
      <section className={`section ${visibleSections.has('skills') ? 'visible' : ''}`} id="skills">
        <h2 className="section-title">My Skills & Tools</h2>
        <div className="skills-grid">
          {skills.map((skill, index) => (
            <div key={index} className="skill-card">
              <div className="skill-icon">
                {skill.icon}
              </div>
              <h3 className="skill-name">{skill.name}</h3>
              <p className="skill-desc">{skill.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="cta-section">
          <a href="#contact" className="cta-button">Want to collaborate?</a>
        </div>
      </section>

      {/* Fun Facts Section */}
      <section className={`section ${visibleSections.has('facts') ? 'visible' : ''}`} id="facts">
        <h2 className="section-title">A Few Things About Me</h2>
        <div className="fun-facts">
          {funFacts.map((fact, index) => (
            <div key={index} className="fun-fact">
              <span className="fun-fact-icon">{fact.icon}</span>
              <p className="fun-fact-text">{fact.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Closing Quote */}
      <section className="closing-quote">
        <p>"Editing is my ibadat — har client mera mehmaan hai."</p>
      </section>
    </div>
  );
};

export default AboutMe;