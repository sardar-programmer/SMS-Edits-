import React from 'react';
import { Camera, Image, Palette, Heart, Github, Twitter, Instagram, Mail, Globe, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="pic-editor-footer">
      <div className="footer-container">
        {/* Main Footer Content */}
        <div className="footer-main">
          {/* Brand Section */}
          <div className="footer-brand">
            <div className="brand-logo">
              <Camera className="logo-icon" />
              <span className="brand-name">SM3S Image Studio</span>
            </div>
            <p className="brand-description">
              Professional photo editing made simple. Transform your images with powerful tools and creative filters.
            </p>
            <div className="social-links">
              <a href="#" className="social-link" aria-label="GitHub">
                <Github />
              </a>
              <a href="#" className="social-link" aria-label="Twitter">
                <Twitter />
              </a>
              <a href="#" className="social-link" aria-label="Instagram">
                <Instagram />
              </a>
              <a href="#" className="social-link" aria-label="Email">
                <Mail />
              </a>
            </div>
          </div>

          {/* Features Section */}
          <div className="footer-section">
            <h3 className="footer-title">
              <Image className="section-icon" />
              Features
            </h3>
            <ul className="section-links">
              <li><a href="#">Basic Editing</a></li>
              <li><a href="#">Advanced Filters</a></li>
              <li><a href="#">Color Correction</a></li>
              <li><a href="#">Batch Processing</a></li>
              <li><a href="#">AI Enhancement</a></li>
            </ul>
          </div>

          {/* Tools Section */}
          <div className="footer-section">
            <h3 className="footer-title">
              <Palette className="section-icon" />
              Tools
            </h3>
            <ul className="section-links">
              <li><a href="#">Crop & Resize</a></li>
              <li><a href="#">Background Remove</a></li>
              <li><a href="#">Text & Watermark</a></li>
              <li><a href="#">Layer Management</a></li>
              <li><a href="#">Export Options</a></li>
            </ul>
          </div>

          {/* Contact Section */}
          <div className="footer-section">
            <h3 className="footer-title">
              <Mail className="section-icon" />
              Contact Us
            </h3>
            <div className="contact-details">
              <div className="contact-item">
                <Mail className="contact-icon" />
                <a href="mailto:hello@piceditpro.com">sardarmustafa987y@gmail.com</a>
              </div>
              <div className="contact-item">
                <Phone className="contact-icon" />
                <a href="tel:+1234567890">+92 3351982621</a>
              </div>
              <div className="contact-item">
                <MapPin className="contact-icon" />
                <span>Dera ismail khan, Pakistan</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom">
          <div className="footer-bottom-left">
            <p>&copy; {currentYear} SM3S Edits. All rights reserved.</p>
            <div className="legal-links">
              <a href="#">Privacy Policy</a>
              <span className="separator">•</span>
              <a href="#">Terms of Service</a>
              <span className="separator">•</span>
              <a href="#">Cookie Policy</a>
            </div>
          </div>
          <div className="footer-bottom-right">
            <div className="made-with-love">
              Made with <Heart className="heart-icon" /> for creators
            </div>
            <div className="version-info">
              <Globe className="globe-icon" />
              v2.1.0
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .pic-editor-footer {
          background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
          color: #e0e0e0;
          padding: 60px 0 20px;
          margin-top: auto;
          position: relative;
          overflow: hidden;
        }

        .pic-editor-footer::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 1px;
          background: linear-gradient(90deg, transparent, #4f46e5, #06b6d4, #10b981, transparent);
          animation: shimmer 3s ease-in-out infinite;
        }

        @keyframes shimmer {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }

        .footer-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 20px;
        }

        .footer-main {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr 1fr;
          gap: 40px;
          margin-bottom: 40px;
        }

        .footer-brand {
          grid-column: span 1;
        }

        .brand-logo {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
        }

        .logo-icon {
          width: 32px;
          height: 32px;
          color: #4f46e5;
          filter: drop-shadow(0 0 8px rgba(79, 70, 229, 0.3));
        }

        .brand-name {
          font-size: 24px;
          font-weight: 700;
          background: linear-gradient(45deg, #4f46e5, #06b6d4);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .brand-description {
          font-size: 14px;
          line-height: 1.6;
          color: #a0a0a0;
          margin-bottom: 24px;
        }

        .social-links {
          display: flex;
          gap: 12px;
        }

        .social-link {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 40px;
          height: 40px;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 10px;
          color: #a0a0a0;
          text-decoration: none;
          transition: all 0.3s ease;
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .social-link:hover {
          background: rgba(79, 70, 229, 0.2);
          color: #4f46e5;
          transform: translateY(-2px);
          box-shadow: 0 4px 20px rgba(79, 70, 229, 0.3);
        }

        .social-link svg {
          width: 18px;
          height: 18px;
        }

        .footer-section {
          display: flex;
          flex-direction: column;
        }

        .footer-title {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 16px;
          font-weight: 600;
          margin-bottom: 20px;
          color: #ffffff;
        }

        .section-icon {
          width: 20px;
          height: 20px;
          color: #10b981;
        }

        .contact-details {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .contact-item {
          display: flex;
          align-items: center;
          gap: 12px;
          font-size: 14px;
        }

        .contact-icon {
          width: 18px;
          height: 18px;
          color: #06b6d4;
          flex-shrink: 0;
        }

        .contact-item a {
          color: #a0a0a0;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .contact-item a:hover {
          color: #4f46e5;
        }

        .contact-item span {
          color: #a0a0a0;
        }

        .section-links {
          list-style: none;
          padding: 0;
          margin: 0;
        }

        .section-links li {
          margin-bottom: 12px;
        }

        .section-links a {
          color: #a0a0a0;
          text-decoration: none;
          font-size: 14px;
          transition: all 0.3s ease;
          position: relative;
        }

        .section-links a:hover {
          color: #4f46e5;
          padding-left: 8px;
        }

        .section-links a::before {
          content: '';
          position: absolute;
          left: -12px;
          top: 50%;
          transform: translateY(-50%);
          width: 0;
          height: 2px;
          background: linear-gradient(45deg, #4f46e5, #06b6d4);
          transition: width 0.3s ease;
        }

        .section-links a:hover::before {
          width: 6px;
        }

        .footer-bottom {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: 30px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          flex-wrap: wrap;
          gap: 20px;
        }

        .footer-bottom-left {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .footer-bottom-left p {
          margin: 0;
          font-size: 14px;
          color: #a0a0a0;
        }

        .legal-links {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
        }

        .legal-links a {
          color: #a0a0a0;
          text-decoration: none;
          transition: color 0.3s ease;
        }

        .legal-links a:hover {
          color: #4f46e5;
        }

        .separator {
          color: #555;
        }

        .footer-bottom-right {
          display: flex;
          align-items: center;
          gap: 24px;
        }

        .made-with-love {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 14px;
          color: #a0a0a0;
        }

        .heart-icon {
          width: 16px;
          height: 16px;
          color: #ef4444;
          animation: heartbeat 2s ease-in-out infinite;
        }

        @keyframes heartbeat {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.1); }
        }

        .version-info {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #666;
          background: rgba(255, 255, 255, 0.05);
          padding: 6px 12px;
          border-radius: 20px;
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .globe-icon {
          width: 14px;
          height: 14px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .footer-main {
            grid-template-columns: 1fr 1fr;
            gap: 30px;
          }

          .footer-brand {
            grid-column: span 2;
          }
        }

        @media (max-width: 480px) {
          .pic-editor-footer {
            padding: 40px 0 20px;
          }

          .footer-main {
            grid-template-columns: 1fr;
            gap: 30px;
          }

          .footer-brand {
            grid-column: span 1;
          }

          .footer-bottom {
            flex-direction: column;
            text-align: center;
            gap: 16px;
          }

          .footer-bottom-right {
            flex-direction: column;
            gap: 12px;
          }

          .legal-links {
            flex-wrap: wrap;
            justify-content: center;
          }
        }
      `}</style>
    </footer>
  );
};

export default Footer;