import React, { useState, useEffect } from 'react';
import { Instagram, MessageCircle, Eye, Quote, Menu, X, Sparkles, Camera, Zap, Palette, ImagePlay } from 'lucide-react';
import './App.css';
import './index.css'
import PortfolioGallery from './gallery.jsx'
import ServicesSection from './services.jsx'
import AboutMe from './about.jsx'
import Footer from './footer.jsx'
import OwnerVisionSection from './owner.jsx'

export default function PhotoEditorHero() {

  const [isLoaded, setIsLoaded] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const FloatingElement = ({ children, delay = 0, className = "" }) => (
    <div
      className={`floating-element ${className}`}
      style={{
        animationDelay: `${delay}s`
      }}
    >
      {children}
    </div>
  );

  return (
    <div className="hero-container">
      {/* Animated background elements */}
      <div className="background-orbs">
        <div className="orb orb-1"></div>
        <div className="orb orb-2"></div>
        <div className="orb orb-3"></div>
      </div>

      {/* Noise texture overlay */}
      <div className="noise-overlay"></div>

      {/* Navigation */}
      <nav className="navigation">
        <div className="nav-container">
          {/* Logo */}
          <div className={`logo ${isLoaded ? 'loaded' : ''}`}>
            <div className="logo-icon">
              <Camera size={24} />
            </div>
            <span className="logo-text">SM3S Image Studio</span>
          </div>

          {/* Desktop Navigation */}
          <div className={`desktop-nav ${isLoaded ? 'loaded' : ''}`}>
            
          </div>

         
        </div>


      </nav>

      {/* Hero Content */}
      <div className="hero-content">
        <div className="hero-grid">
          {/* Left Side - Text Content */}
          <div className="text-content">
            <div className={`main-heading ${isLoaded ? 'loaded' : ''}`}>
              <h1>
                Turn Your Photos
                <span className="gradient-text">Into Art.</span>
              </h1>
            </div>

            <div className={`subheading ${isLoaded ? 'loaded' : ''}`}>
              <div className="glass-card">
                <p>Professional Retouch, Creative Touch, & Classy Results.</p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className={`cta-buttons ${isLoaded ? 'loaded' : ''}`}>
              <button className="primary-btn">
                <Eye size={20} />
                <span>View Portfolio</span>
              </button>
              <button className="secondary-btn">
                <Quote size={20} />
                <span>Get a Quote</span>
              </button>
            </div>

            {/* Social Icons */}
            <div className={`social-icons ${isLoaded ? 'loaded' : ''}`}>
              <a href="#" className="social-icon instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="social-icon whatsapp">
                <MessageCircle size={20} />
              </a>
              <a href="#" className="social-icon behance">
                <Eye size={20} />
              </a>
            </div>
          </div>

          {/* Right Side - Image */}
          <div className={`image-content ${isLoaded ? 'loaded' : ''}`}>
            {/* Main Image Container */}
            <div className="image-container">
              <div className="image-wrapper">
                <div className="image-overlay"></div>
                <img
                  src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=800&fit=crop&auto=format"
                  alt="Professional Photo Edit"
                  className="main-image"
                />
                <div className="image-border"></div>
              </div>

              {/* Floating Elements */}
              <FloatingElement delay={0} className="float-1">
                <div className="float-icon sparkles">
                  <Sparkles size={24} />
                </div>
              </FloatingElement>

              <FloatingElement delay={1} className="float-2">
                <div className="float-icon palette">
                  <Palette size={28} />
                </div>
              </FloatingElement>

              <FloatingElement delay={2} className="float-3">
                <div className="float-icon zap">
                  <Zap size={20} />
                </div>
              </FloatingElement>

              {/* Glow effect */}
              <div className="image-glow"></div>
            </div>

            {/* Stats Cards */}
            <div className="stats-cards">
              <div className="stat-card">
                <div className="stat-number">500+</div>
                <div className="stat-label">Projects</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">50+</div>
                <div className="stat-label">Clients</div>
              </div>
              <div className="stat-card">
                <div className="stat-number">5★</div>
                <div className="stat-label">Rating</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="bottom-fade"></div>
      <AboutMe />
      <PortfolioGallery />
      <ServicesSection />
      <OwnerVisionSection />
      <Footer></Footer>
    </div>
  );
}
